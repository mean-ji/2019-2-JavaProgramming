import javax.swing.*;
import java.awt.*;

public class CH15_RecorderWindowMain {
	public static void main(String[] args) { 
		CH15_RecorderWindow window1 = new CH15_RecorderWindow(); 
		window1.setVisible(true);
	}
}
