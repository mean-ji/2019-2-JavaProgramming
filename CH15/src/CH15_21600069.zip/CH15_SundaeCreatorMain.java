import javax.swing.*;
import java.awt.*;

public class CH15_SundaeCreatorMain {
	public static void main(String[] args) {
		CH15_SundaeCreator window1 = new CH15_SundaeCreator();
		window1.setVisible(true);
	}

}
