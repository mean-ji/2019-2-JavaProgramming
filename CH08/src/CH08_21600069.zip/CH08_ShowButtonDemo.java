
	public class CH08_ShowButtonDemo{
			public static void main(String[] args){
				CH08_ButtonDemo gui = new CH08_ButtonDemo( );
				gui.setVisible(true);
			}
}