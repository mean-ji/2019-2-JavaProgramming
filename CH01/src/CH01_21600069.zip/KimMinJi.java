import java.util.*;
public class KimMinJi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("school: Handong University");
		System.out.println("name: KimMinJi");
		System.out.println("student Id: 21600069");

	}

}
