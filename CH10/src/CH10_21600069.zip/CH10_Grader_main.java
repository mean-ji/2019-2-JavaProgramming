
public class CH10_Grader_main {
	public static void main(String[] args) {
		String fileName = "StudentGrades.txt";
		String outfileName = "StudentGrades_average.txt";
		CH10_Grader.run(fileName,outfileName);
	}

}
