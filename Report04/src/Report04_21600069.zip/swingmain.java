import javax.swing.*;
import java.awt.*;

public class swingmain {
	public static void main(String[] args) {
		swing window1 = new swing();
		window1.setVisible(true);
	}

}

