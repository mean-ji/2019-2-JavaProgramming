import javax.swing.*;
import java.awt.*;

public class CH13_KeypadWIndowMain{
	public static void main(String[] args) { 
		CH13_KeypadWindow window1 = new CH13_KeypadWindow();
		window1.setVisible(true);
	}
}
