import javax.swing.*;
import java.awt.*;


public class CH13_CreditCardWindowMain {
	public static void main(String[] args) {
		CH13_CreditCardWindow window1 = new CH13_CreditCardWindow();
		window1.setVisible(true);
	}
}
